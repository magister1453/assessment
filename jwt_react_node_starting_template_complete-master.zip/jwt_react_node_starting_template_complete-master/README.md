# jwt_react_node_starting_template
This is a starting template for a Medium Article.

https://medium.com/@romanchvalbo/how-i-set-up-react-and-node-with-json-web-token-for-authentication-259ec1a90352
